<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trans_model extends CI_Model { 



 

 
 
 //this method adds students to the database
 public function add_student()
 {
	  
	 //getting the inputs sent through post
	   $students_name    = $this->input->post('student_name');
	   $reg_num          = $this->input->post('reg_num');
	   $dept             = $this->input->post('dept');
	   $faculty          = $this->input->post('faculty');
	   $date_admit       = $this->input->post('date_admit');
	   
	   
	   
	   $data = array(
	   
	      'student_name' => $students_name,
		  'reg_num'      => $reg_num,
		  'dept'         => $dept,
		  'faculty'      => $faculty,
		  'date_admit'   => $date_admit,
	   
	   );
	   
	   //inserting the student
	   $insert = $this->db->insert('student', $data);
	   return $insert;
	
 }
 
 

 
  //this method adds students to the database
 public function add_lecturer()
 {
	  
	 //getting the inputs sent through post
	   $lecturer_name    = $this->input->post('lecturer_name');
	   $level          = $this->input->post('level');
	   $dept             = $this->input->post('dept');
	   $uname          = $this->input->post('uname');
	   $password       = $this->input->post('password');
	   
	   
	   
	   $data = array(
	   
	      'lecturer_name' => $lecturer_name,
		  'level_id'      => $level,
		  'dept'         => $dept,
		  'uname'      => $uname,
		  'password'   => $password,
	   
	   );
	   
	   //inserting the student
	   $insert = $this->db->insert('lecturers', $data);
	   return $insert;
	
 }



 //this method gets all students
 public function get_all_student()
 {
	 
    $q = $this->db->get('student');
    return $q->result_array();
 
 }
 
 
 //this method get student info by id 
 public function get_student_info($student_id)
 {
	 
   $this->db->select('student.*');
   $this->db->where('student_id', $student_id);
   $q = $this->db->get('student');
   return $q->row();
   
 }


 //this method adds fubc
 public function add_course()
 {
	 
   $course_title = $this->input->post('course_title');
   $course_code = $this->input->post('course_code');
   $credits = $this->input->post('credits');
   $level = $this->input->post('level');
   $semester = $this->input->post('semester');
   
   $data = array(
   
     'course_code' => $course_code,
	 'course_title' => $course_title,
	 'credits'    => $credits,
	 'level_id'  => $level,
	 'semester'   => $semester,
   
   );
   
   $insert = $this->db->insert('courses', $data);
   return $insert;
 
 }
 
 
 
 //this method gets levels
 public function get_levels()
 {
  
    $this->db->select('levels.*');
	$q = $this->db->get('levels');
	return $q->result_array();	 
 
 }
 
 



//this method get course for ajax sugestion 
public function get_course_dropdown_info($semester)
{
   
   $this->db->select('courses.*');
   $this->db->where('semester',$semester);
   $q = $this->db->get('courses');
   return $q->result_array();


}


 //this method gets course title and credits
 public function get_course_info_by_id($course_id)
 {
	 
	 $this->db->select('courses.*');
	 $this->db->where('course_id', $course_id);
	 
	 $q = $this->db->get('courses');
	 return $q->result_array();
	 
 }



//this method insert first transcript into the db
public function insert_first_trans()
{
            //getting the values
			$student_id = $this->input->post('student_id');
			$level_id = $this->input->post('level_id');
			$course_id = $this->input->post('course_id');
			$grade_point = $this->input->post('grade_point');
			$point_earn = $this->input->post('point_earn');
			$semester_id = $this->input->post('semester_id');
			
			$data = array();
			for($i=0; $i<count($course_id); $i++){
		       		
			  $data[$i] = array(
			  
			  'student_id'   => $student_id,
			  'level_id'     => $level_id,
			  'course_id'    => $course_id[$i],
	          'grade_point'  => $grade_point[$i],
	          'point_earned' => $point_earn[$i],
			  'semester_id'  => $semester_id,
			  
			  
			   );
			
			}
	
	
	
	 $insert = $this->db->insert_batch('student_course', $data);
	 return $insert;
   

}



//this method inserts the total gpa , credit_load , point_earn
public function insert_total_gpa()
{
	     
	    //getting the values
	    $student_id   = $this->input->post('student_id');
		$level_id     = $this->input->post('level_id');
		$student_gpa  = to_2d_place($this->input->post('student_gpa'));
		$credit       = $this->input->post('credit');
		$point        = $this->input->post('point');
		$semester_id  = $this->input->post('semester_id');
		
		//setting an array of data
		$data = array(
		
		  'semester_id'       => $semester_id,
		  'level_id'          => $level_id,
		  'student_id'        => $student_id,
		  'total_credit_load' => $credit,
		  'total_point_earn'  => $point,
		  'gpa'               => $student_gpa,
		
		);
		
	$insert = $this->db->insert('tcredit_and_tpoint', $data);
	return $insert;	

}



//this method gets the current student_info
public function get_current_info($student_id)
{
	
   $this->db->select('student.*');
   $this->db->where('student_id', $student_id);
   
   $q = $this->db->get('student');
   return $q->result_array();
   
}




//this method updates student info
public function update_student_info($updated_credit,$updated_point, $updated_cgpa, $student_id )
{
    //making an array of the datas
	$data = array(
	
	  'cgpa' => round($updated_cgpa,2),
	  'total_credit_load' => $updated_credit,
	  'total_point_earn'  => $updated_point,
	
	);	
	
	$this->db->where('student_id', $student_id);
	$update = $this->db->update('student', $data);
	return $update;
	
}



/*this method gets unique students info
public function get_student_info($student_id)
{
   $this->db->where('student_id', $student_id);
   $this->db->limit(1);
   $q = $this->db->get('student');
   return $q->row();	

}
*/



//this method gets the students  registered courses detail
public function get_student_course_info($student_id, $level_id, $semester)
{
   
   $this->db->select('student_course.*, courses.*, student.*, semester.semester_id');
   $this->db->from('student_course');
   $this->db->join('courses', 'courses.course_id=student_course.course_id');
   $this->db->join('student', 'student.student_id=student_course.student_id');
   $this->db->join('levels', ';levels.level_id=student_course.level_id');
   $this->db->join('semester', 'semester.semester_id=student_course.semester_id');
   $this->db->where('student.student_id', $student_id);
   $this->db->where('levels.level_id', $level_id);
   $this->db->where('semester.semester_id',$semester);
   $q = $this->db->get();
   return $q->result_array();

} 


//this method gets the student total credit load for the semester
public function get_student_credit_load($student_id, $level_id, $semester)
{
	$this->db->select('tcredit_and_tpoint.*, student.student_id, levels.*, semester.semester_id');
	$this->db->from('tcredit_and_tpoint');
	$this->db->join('student', 'student.student_id=tcredit_and_tpoint.student_id');
	$this->db->join('levels', 'levels.level_id=tcredit_and_tpoint.level_id');
	$this->db->join('semester', 'semester.semester_id=tcredit_and_tpoint.semester_id');
	$this->db->where('student.student_id', $student_id);
	$this->db->where('levels.level_id', $level_id);
	$this->db->where('semester.semester_id',$semester);
	$q = $this->db->get();
	return $q->row();

}





//this method gets all student for dashboard
public function get_student_count()
{
   
   $q = $this->db->get('student');
   return $q->num_rows();	

}



//this method gets number of transcript 
public  function get_transcript_count()
{
	
    $q = $this->db->get('tcredit_and_tpoint');
	return $q->num_rows();

}


//this method gets all courses 
public function get_courses_count()
{
   $q = $this->db->get('courses');	
   return $q->num_rows();
}




//this method gets lecturers
public function get_lecturers()
{
   
   $this->db->select('lecturers.*, levels.*');
   $this->db->from('lecturers');
   $this->db->join('levels', 'levels.level_id=lecturers.level_id');	
  
   $q = $this->db->get();
   return $q->result_array();

}














}//end of class