<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

   public function __construct()
   {
	   parent::__construct();   
   }
   
   
   
   //this method display home page
   public function index()
   {
	   
     $data['title'] = 'Transript Manager';
	 $data['main'] = 'public/home';
	 $this->load->view('templates/templates_home', $data);
   
   }






}//end of class