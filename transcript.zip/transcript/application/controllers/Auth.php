<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

   public function __construct()
   {
	   parent::__construct();   
   }
   
   
   
      //This method logs in a user into the app
   public function login()
   {
      if(isset($_POST['email']) && isset($_POST['password']) && isset($_POST['account_type'])){
		  
		          $email = $this->input->post('email');
	             $password = $this->input->post('password');
		         $account_type = (int)$this->input->post('account_type');
				
				$auth = $this->Auth_model->login($email, $password, $account_type);
				if($auth){
					
					  //echo base_url() .'public/dashboard';
					  
					      $user_level = (int)$this->session->userdata('user_level');
						  
						  
						  if($user_level === 1){
							     
								 echo base_url() .'admin/dashboard';
								 
								 
							  
							  }else{
								  
								    echo base_url() .'lecturer/dashboard';
								
								  }
					
					}else{
						
						  echo 'error';
						
						}
				
		  }
      
   
   }
   	
	
	

     /*
   *@logout method
   *@description this logout the user and kills the session
   **/
	public function logout(){
		
		$this->Auth_model->logout(); 
		redirect('home');
		   
	}


/*
   public function logout_lec(){
		
		$this->Auth_model->logout_lec(); 
		redirect('home');
		   
	}


*/





}//end of class