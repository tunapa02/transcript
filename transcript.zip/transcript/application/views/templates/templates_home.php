<?php $this->load->view('includes/header_home');?>





<?php $this->load->view($main); ?>



<?php $this->load->view('includes/footer');?>