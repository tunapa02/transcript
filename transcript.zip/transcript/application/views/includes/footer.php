   <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/js/app.js"></script>
    
    <script>
      var baseURL = '<?php echo base_url(); ?>';
	  
	   $(document).ready(function(){
         
         $('#btn-open').css("display", "none");
         
     })    
        
        
      $('#btn-close').on('click', function(){
          
          $('#btn-open').css("display", "");
          $('#btn-close').css("display", "none");
          $('#div-nav').hide();
          
          $('#div-main').removeClass('col-md-10');
          $('#div-main').addClass('col-md-12');
          
      }) 
      
       $('#btn-open').on('click', function(){
          
          $('#btn-close').css("display", "");
          $('#btn-open').css("display", "none");
          $('#div-nav').show();
          $('#div-main').removeClass('col-md-12');
          $('#div-main').addClass('col-md-10');
          
      })  
	  
    </script>
 
  </body>
</html>
