
            
          <div id="div-main" class="col-md-10 animated">
              <!-- dashboard datas -->
                 
                 <div class="row">
               
                  
                      <div class="col-md-6">
                         <div class="well bg-green">
                           <h1><i class="fa fa-user-circle fa-4x"></i> 3</h1>
                           <h3>All Lecturers</h3>
                          
                         </div>
                      </div>
                   
                     <div class="col-md-6">
                        <div class="well btn-red">
                           <h1><i class="fa fa-graduation-cap fa-4x"></i> 19</h1>
                           <h3>All Courses</h3>
                          
                         </div>
                     </div> 
              
                 </div>
              
              <!-- dashboard -->
              
           
               <div class="row">
               
                   <!-- button -->
                   <div class="text-center">
                      <!-- <h3>All Studenst</h3> -->   
                    </div> 
                   <!--- buttons -->
                   <br />
               
                  <div class="col-md-12">
                  
                  
                  <div class="panel panel-primary">
                      <div class="panel-heading">
                        <h3 class="panel-title">All Lecturers</h3>
                      </div>
                      <div class="panel-body">
                        <table class="table table-striped table-bordered">
                       <tr>
                           <th>Lecturer Name</th>
                           <th>Department</th>
                           <th>Level</th>
                           <th>Username</th>
                           <th>Password</th>
                           
                       </tr>
                       <?php foreach($lecturers as $lect):?>
                       <tr>
                         <td on><?php echo $lect['lecturer_name'];?></td>
                         <td><?php echo $lect['level_title'];?></td>
                         <td><?php echo $lect['dept'];?></td>
                         <td><?php echo $lect['uname']; ?></td>
                         <td><?php echo $lect['password']; ?></td>
                        
                       </tr>
                       <?php endforeach;?>  
                     </table> 
                     
                      </div>
                    </div>
                  
                    
                     
                  </div>
                     
                     
              
                 </div>
              
              
              
              
          </div>    
        </div>
      </div>
      
    <!--/ end lecturers dashboard -->   
      
   
   