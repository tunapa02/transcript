<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

  <div class="col-md-2"></div>
  <div class="col-md-6">
    <div class="well text-center">
    <h3>Add Course</h3>
    <div id="feedback_add_course"></div>
      <form id="form_add_course" method="POST" action="<?php echo base_url();?>lecturer/dashboard/add_course">
    Course Title<br />
    <input type="text" id="course_title" name="course_title" class="form-control" /><br />
    Course Code<br />
    <input type="text" id="course_code" name="course_code" class="form-control" /><br />
    Credits Load<br />
    <input type="text" id="credits" name="credits" class="form-control" /><br />
    Level<br />
    
     <select name="level" id="level" class="form-control">
       <option>Select Level</option>
       <option value="1">Level 100</option>
       <option value="2">Level 200</option>
       <option value="3">Level 300</option>
       <option value="4">Level 400</option>
       
    </select>
    <br />
    Semester<br />
    <select name="semester" id="semester" class="form-control">
       <option>Select Semester</option>
       <option value="1">First Semester</option>
       <option value="2">Second Semester</option>
       
    </select>
    <br />
    <input type="submit" value="Add Course" id="mysubmit" />
    
  </form>
    </div>
  </div>
  <div class="col-md-4"></div>
 

</body>
</html>

  