     
          <div id="div-main" class="col-md-10 animated">
              <!-- dashboard datas -->
                <div class="row">
                   <div class="col-md-12">
                      <div class="panel panel-default">
                      <div class="panel-body">
                        <!-- school intro-->
                         <div class="skool-info text-center">
                           <img src="<?php echo base_url();?>assets/img/tran.jpg" class="pull-left" style="border:1px solid #000;">
                            <h4>USMAN DANFODIO UNIVERSITY<h4>
                           <h5>Katsina State, Nigeria</h5>
                           <h4>STUDENT REPORT FORM</h4> 
                         </div>
                        <!-- school intro -->
                        
                        <!-- student info -->
                          
                            <div class="student-info">
                              <p>NAME : <?php echo strtoupper($student_details->student_name); ?></p>
                              <p>REGISTRATION NUMBER : <?php echo strtoupper($student_details->reg_num);?></p>
                              <P>FACULTY : <?php echo strtoupper($student_details->faculty);?></P>
                              <P>DEPARTMENT : <?php echo strtoupper($student_details->dept);?></P>
                          
                               <input id="student_id" type="hidden" value="<?php echo $student_details->student_id;?>" />
                              <br><br>
                              </div>
                            
                        <!-- student info -->
                          
                              <!-- select year input -->
                             <div class="input-data"> 
                              <div class="row">
                                <div class="col-md-4">
                                 <P><?php if(count($student_total_first)):echo $student_total_first->level_title; endif;?></P>
                                </div>
                                <div class="col-md-4">
                                 
                                </div>
                                <div class="col-md-4">
                                  <p>CURRENT CGPA : <?php echo $student_details->cgpa?></p>
                                  <div id="list_of_code"></div>
                                </div>
                              </div> 
                              </div>
                              <!-- select year input -->
                              
                            
                        
                        
                      </div>
                    </div>
                   </div>
                   
                   <div  id="" class="col-md-12 ">
                     <div class="panel panel-default">
                      <div class="panel-body">
                        
                        <!-- table for first semester records -->
                             <h3 class="text-center">FIRST SEMESTER RESULT</h3>
                             <input id="semester_id" type="hidden" value="1"  />
                             <table class="table table-bordered" id="new_row_first">
                                <tr>
                                  <th>Code</th>
                                  <th>Course Title</th>
                                  <th>Credits</th>
                                  <th>Grade</th>
                                  <th>GP</th>
                                  <th>PE</th>
                                </tr>
                                <?php foreach($student_transcript_first as $trans_first):?>
                                <tr>
                                  <td><?php echo $trans_first['course_code'];?></td>
                                  <td><?php echo $trans_first['course_title'];?></td>
                                  <td><?php echo $trans_first['credits'];?></td>
                                  <td><?php echo convert_to_alpha((int)$trans_first['grade_point']);?></td>
                                  <td><?php echo $trans_first['grade_point'];?></td>
                                  <td><?php echo $trans_first['point_earned'];?></td>
                                </tr>
                                <?php endforeach;?>
                                   
                             
                             </table> 
                             <div class="row">
                              <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Credit Load</th>
                                 <th id="total_credit_first"><?php if(count($student_total_first)):echo $student_total_first->total_credit_load; endif;?></th>
                               </tr>
                             </table>
                              </div>
                                <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Point Earn</th>
                                 <th id="total_point_first"><?php if(count($student_total_first)):echo $student_total_first->total_point_earn; endif;?></th>
                               </tr>
                             </table>
                              </div>
                              
                               <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>GPA</th>
                                 <th id="gpa_first"><?php if(count($student_total_first)):echo to_2d_place($student_total_first->gpa); endif;?></th>
                               </tr>
                             </table>
                              </div>
                              <div id="feedback" class="col-md-12">
                                    
                              </div>
                              
                             </div>
                             
                             
                        <!-- table for first first records -->
                        <hr>
                        
                        
                         <!-- table for first semester records  -->
                             <h3 class="text-center">SECOND SEMESTER RESULT</h3>
                             <table class="table table-bordered" id="">
                                <tr>
                                
                                <th>Code</th>
                                <th>Course Title</th>
                                <th>Credits</th>
                                <th>Grade</th>
                                <th>GP</th>
                                <th>PE</th>
                                </tr>
                                
                                <?php foreach($student_transcript_second as $trans_second):?>
                                <tr>
                                  <td><?php echo $trans_second['course_code'];?></td>
                                  <td><?php echo $trans_second['course_title'];?></td>
                                  <td><?php echo $trans_second['credits'];?></td>
                                  <td><?php echo convert_to_alpha((int)$trans_second['grade_point']);?></td>
                                  <td><?php echo $trans_second['grade_point'];?></td>
                                  <td><?php echo $trans_second['point_earned'];?></td>
                                </tr>
                                <?php endforeach;?>
                             </table>
                             
                             
                             <div class="row">
                              <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Credit Load</th>
                                 <th id="total_credit_second"><?php if(count($student_total_second)):echo $student_total_second->total_credit_load; endif;?></th>
                               </tr>
                             </table>
                              </div>
                                <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>Total Point Earn</th>
                                 <th id="total_point_second"><?php if(count($student_total_second)):echo $student_total_second->total_point_earn; endif;?></th>
                               </tr>
                             </table>
                              </div>
                              
                               <div class="col-md-3">
                               <table class="table table-striped">
                               <tr>
                                 <th>GPA</th>
                                 <th id="gpa_second"><?php if(count($student_total_second)):echo to_2d_place($student_total_second->gpa); endif;?></th>
                               </tr>
                             </table>
                              </div>
                              <div class="col-md-3">
                                     <table class="table table-striped">
                                       <tr>
                                         <th>CGPA</th>
                                         <th><?php echo strtoupper($student_details->cgpa);?></th>
                                       </tr>
                                     </table>
                                  </div>
                               
                               <!-- button to generate pdf -->
                                 <div class="col-md-12 text-center">
                                    <a target="_blank" href="<?php echo base_url();?>lecturer/dashboard/get_pdf/<?php echo $student_details->student_id.'/'.$student_total_first->level_id;?>" class="btn btn-success btn-lg"><i class="fa fa-download"></i> Generate</a>
                                 </div>  
                               <!-- button to generate pdf -->   
                                 
                              
                              </div>
                              
                        <!-- <table for first semester records -->
                     
                         
                           
                      </div>
                    </div>
                   </div>
                </div>
              <!-- dashboard -->
          </div>    
        </div>
      </div>
      
    <!--/ end lecturers dashboard -->   
      
   
   